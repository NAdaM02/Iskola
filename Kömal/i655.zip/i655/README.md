A program a 3. verziójú python interpreterrel futtatható.
'python main.py' vagy 'python3 main.py'